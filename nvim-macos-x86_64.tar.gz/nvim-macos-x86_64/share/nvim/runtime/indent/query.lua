-- Neovim indent file
-- Language:	Treesitter query
-- Last Change:	2024 Jul 03

-- it's a lisp!
vim.cmd([[runtime! indent/lisp.vim]])
